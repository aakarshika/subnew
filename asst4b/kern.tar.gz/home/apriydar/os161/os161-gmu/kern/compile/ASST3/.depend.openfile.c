openfile.o: ../../syscall/openfile.c ../../include/types.h \
  ../../include/kern/types.h includelinks/kern/machine/types.h \
  includelinks/machine/types.h ../../include/kern/errno.h \
  ../../include/kern/fcntl.h ../../include/lib.h ../../include/cdefs.h \
  opt-noasserts.h ../../include/synch.h ../../include/spinlock.h \
  includelinks/machine/spinlock.h ../../include/vfs.h \
  ../../include/array.h ../../include/openfile.h
