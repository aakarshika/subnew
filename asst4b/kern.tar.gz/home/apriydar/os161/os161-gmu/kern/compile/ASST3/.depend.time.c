time.o: ../../lib/time.c ../../include/types.h ../../include/kern/types.h \
  includelinks/kern/machine/types.h includelinks/machine/types.h \
  ../../include/clock.h ../../include/kern/time.h
