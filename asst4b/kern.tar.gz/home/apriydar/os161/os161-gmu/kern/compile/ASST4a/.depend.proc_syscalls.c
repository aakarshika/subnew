proc_syscalls.o: ../../syscall/proc_syscalls.c ../../include/types.h \
  ../../include/kern/types.h includelinks/kern/machine/types.h \
  includelinks/machine/types.h ../../include/kern/errno.h \
  ../../include/kern/syscall.h ../../include/kern/fcntl.h \
  ../../include/kern/limits.h ../../include/kern/seek.h \
  ../../include/kern/stat.h ../../include/kern/wait.h ../../include/lib.h \
  ../../include/cdefs.h opt-noasserts.h ../../include/uio.h \
  ../../include/kern/iovec.h ../../include/proc.h \
  ../../include/spinlock.h includelinks/machine/spinlock.h \
  ../../include/thread.h ../../include/array.h ../../include/threadlist.h \
  includelinks/machine/thread.h ../../include/setjmp.h \
  includelinks/kern/machine/setjmp.h ../../include/vfs.h \
  ../../include/vnode.h ../../include/openfile.h \
  ../../include/filetable.h ../../include/limits.h \
  ../../include/current.h includelinks/machine/current.h \
  ../../include/synch.h ../../include/copyinout.h \
  includelinks/mips/trapframe.h ../../include/addrspace.h \
  ../../include/vm.h includelinks/machine/vm.h opt-dumbvm.h \
  ../../include/syscall.h
