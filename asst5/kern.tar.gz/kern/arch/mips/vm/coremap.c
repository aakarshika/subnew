#include <types.h>
#include <kern/errno.h>
#include <lib.h>
#include <spl.h>
#include <cpu.h>
#include <spinlock.h>
#include <proc.h>
#include <current.h>
#include <mips/tlb.h>
#include <addrspace.h>
#include <vm.h>


static struct coremap_e *coremap;
struct spinlock *map_lock;
unsigned sizeofmap;


void initmap(void){

	size_t npages, csize;

	paddr_t firstpaddr, lastpaddr;
	ram_firstlast(&firstpaddr, &lastpaddr);

	map_lock = (struct spinlock*)PADDR_TO_KVADDR(firstpaddr);
	spinlock_init(map_lock);
	size_t locksize = sizeof(struct spinlock);
	locksize = ROUNDUP(locksize, PAGE_SIZE);
	firstpaddr+= locksize;
	
	npages = (lastpaddr - firstpaddr) / PAGE_SIZE;
	
	KASSERT(firstpaddr!=0);
	//DEBUG(DB_VM, "npages= %u\n",npages);
        //DEBUG(DB_VM, "f%x,l%x,n%u\n",firstpaddr,lastpaddr,npages);

	coremap = (struct coremap_e*)PADDR_TO_KVADDR(firstpaddr);
	if(coremap == NULL){
		panic("Unable to create Coremap....\n");
	}
       // kprintf("fp%x,lp%x,n%u\n",firstpaddr,lastpaddr,npages);

	csize = npages * sizeof(struct coremap_e);
	csize = ROUNDUP(csize, PAGE_SIZE);
	firstpaddr+= csize;
	npages = (lastpaddr - firstpaddr) / PAGE_SIZE;
        //kprintf("fp%x,lp%x,n%u\n",firstpaddr,lastpaddr,npages);

	sizeofmap = npages;
	for(unsigned i = 0; i < npages; i++){
		coremap[i].ps_padder = firstpaddr+(i*PAGE_SIZE);
		coremap[i].ps_swapaddr = 0;
		coremap[i].cpu_index = 0;
		coremap[i].tlb_index = -1;
		coremap[i].block_length = 0;
		coremap[i].is_allocated = 0;
		coremap[i].is_kern = 0;
	}
	//kprintf("c0:%x",coremap[0].ps_padder);
}

vaddr_t alloc_kpages(unsigned npages){
	//unsigned page_count = 0;
        //bool is_kern = (proc_getas() == NULL);
	//spinlock_acquire(map_lock);
	vaddr_t retvaddr = PADDR_TO_KVADDR(alloc_npages(npages));
	
		
	//kprintf("wtf?\n");
	//spinlock_release(map_lock);
	return retvaddr;
}

paddr_t alloc_npages(unsigned npages)
{	unsigned pcount=0;
        //bool is_kern = (proc_getas() == NULL);
        spinlock_acquire(map_lock);
        for(unsigned i = 0; i<sizeofmap; i++){
                if(coremap[i].is_allocated)
                	pcount = 0;
		else
			pcount++;
		if(pcount == npages)
		{
                int start_index = i+1-npages;
                coremap[start_index].block_length = npages;
                for(unsigned j = start_index; j<=i; j++){
                          coremap[j].is_allocated = 1;
                          //coremap[j].is_kern = is_kern;
                }
                paddr_t retpaddr = coremap[start_index].ps_padder;
                spinlock_release(map_lock);
                return retpaddr;
		}
        }
        spinlock_release(map_lock);
        return 0;
}

void free_kpages(vaddr_t addr){
	paddr_t page_ad = KVADDR_TO_PADDR(addr);
	unsigned i=0;
	spinlock_acquire(map_lock);
	for (i=0; i<sizeofmap; i++){
		if(coremap[i].ps_padder == page_ad)
			break;
	}
	if(coremap[i].ps_padder == page_ad){
		KASSERT(coremap[i].is_allocated);
		int j = coremap[i].block_length;
		//kprintf("freeng %d pgs\n",j);
		for(int k=0; k<j; k++){
			coremap[i+k].is_allocated = 0;
			coremap[i+k].block_length = 0;
		//	kprintf("Freeing index: %d\n", (i+k));
		}
	}
	spinlock_release(map_lock);

}

void
vm_bootstrap(void)
{
	initmap();
        //kprintf("VM");

}

unsigned
int
coremap_used_bytes() {

	int count = 0;
	for(unsigned i = 0; i<sizeofmap; i++){
		if(coremap[i].is_allocated){
			count++;
		}
	}
	kprintf("No. of used pages: %d. Total pages: %u\n", count, sizeofmap);
	unsigned int used = count*PAGE_SIZE;

	return used;
}

void
vm_tlbshootdown_all(void)
{
	panic("You tried to do tlb shootdown?!\n");
}

void
vm_tlbshootdown(const struct tlbshootdown *ts)
{
	(void)ts;
	panic("You tried to do tlb shootdown?!\n");
}

int vm_fault(int faulttype, vaddr_t faultaddress){
	//kprintf("PF.v%x\n",faultaddress);
	//kprintf("T.%u\n",faulttype);
	bool valid = false;
	struct addrspace *as = proc_getas(); //current process address
	bool page_permission[3];
	uint32_t tlbhi, tlblo;
	int tlb_index = -8;

	if (as == NULL) {
		//DEBUG(DB_VM,"AS NULL.\n");
		return EFAULT;
	}
	KASSERT(faultaddress == (faultaddress & PAGE_FRAME));
        
	//Check if the address is valid
	struct region *curr_region = as->regionlist;
	
	while(curr_region!=NULL){
		if(faultaddress >= curr_region->vbase &&   faultaddress <= ((curr_region->npages*PAGE_SIZE)+curr_region->vbase)) 
		{
			valid=true;
			break;
		}
		curr_region = curr_region->next;
	}
	if(curr_region!=NULL)
		for(int i=0;i<3;i++)	
		{	
			page_permission[i] = curr_region->permissions[i];
			//kprintf("p%d ",page_permission[i]);
		}

	if (faultaddress >= USERSTACK - PAGE_SIZE * STACKPAGES){
		page_permission[0] = 1;
		page_permission[1] = 1;
		valid = true;
	//	DEBUG(DB_VM, "PF:v in user\n");

	}
	if(!valid){
	//	DEBUG(DB_VM, "IDK THIS ADDRESS.\n");
		return EFAULT;
	}
	
	spinlock_acquire(&as->pt_lock);

	struct pagetable_e *pte = pt_get_page(as, faultaddress>>12);
	
	//if(pte!=NULL) kprintf("PTE-v%x,f%x,p%x\n",pte->vaddr,faultaddress, pte->paddr); else kprintf("PTEnull,f%x\n",faultaddress);
	//kprintf("T:%u\n",faulttype);
	//Check if we have the required permission
	int spl=0;
	//paddr_t paddr = pte->paddr & PAGE_FRAME;

	switch(faulttype){
		case VM_FAULT_READONLY:
			//Check if we can write to the page
			if(!page_permission[1] && !as->loading){
				//DEBUG(DB_VM,"sada problem\n");	
				return EFAULT;
			}
			
		        paddr_t paddr = pte->paddr & PAGE_FRAME;

			paddr_t pbase = paddr<<12;
                        //kprintf("tlpp %x\n",TLBLO_PPAGE);
			vaddr_t vad = faultaddress;
			//DEBUG(DB_VM,"RDNLY:vad %x,pb %x\n",vad,pbase);
			tlbhi = vad & TLBHI_VPAGE;
			tlblo = (pbase & TLBLO_PPAGE)  | TLBLO_DIRTY  | TLBLO_VALID;
			// DEBUG(DB_VM, "hi-%x\n",tlbhi);
                        // DEBUG(DB_VM, "lo-%x\n",tlblo);
			//Get the tlb index for the page
			spl = splhigh();
			tlb_index = tlb_probe(tlbhi, 0);
                        // DEBUG(DB_VM, "lo-%x\n",tlblo);
			//paddr_t hi,lo;
			//tlb_read(&hi,&lo,tlb_index);
			//DEBUG(DB_VM, "ti@%d\n",tlb_index );
			if (tlb_index < 0) {
	                       // DEBUG(DB_VM, "rndmng-");
				//tlblo = (pbase & TLBLO_PPAGE) | TLBLO_VALID;
				tlb_random(tlbhi, tlblo);        
				//DEBUG(DB_VM, "-/\n");

			}
			else {
	                        //DEBUG(DB_VM, "wrtng-");
				tlb_write(tlbhi, tlblo, tlb_index);
				//DEBUG(DB_VM, "-/\n");
			}

			splx(spl);
			spinlock_release(&as->pt_lock);
				//DEBUG(DB_VM, "-/\n");

			return 0;
			
			//panic("READONLY TRIED!!");
		case VM_FAULT_WRITE: 
			//DEBUG(DB_EXEC, "pf:WRT\n");
			break;
		case VM_FAULT_READ: 
			//DEBUG(DB_EXEC, "pf:RD\n");
			break;
		default:
			return EINVAL;
	}
	spl=splhigh();
	//VM_FAULT READ or WRITE. No TLB entry found
	//Check if page is allocated
	if(pte == NULL){
		//Allocating page for the first time
                //DEBUG(DB_VM, "gng2alc\n");
		
		paddr_t newpad = alloc_npages(1);
		if(newpad==0)
			return ENOMEM;
		//bzero((void *)PADDR_TO_KVADDR(newpage), PAGE_SIZE);
		//spinlock_aquire(&pt_lock);
	        //paddr_t newpad = KVADDR_TO_PADDR(newvad);
		//kprintf("newpad %x\n",newpad);
                //vaddr_t checkv = PADDR_TO_KVADDR(newpad);
                //kprintf("allocatednewvad %x\n",newvad);
                //kprintf("cvad %x\n",checkv);
		//as->loading = 1;
		vaddr_t newvad = faultaddress>>12; 
		pt_insert(as, newvad, newpad , page_permission);
		
		//as->loading = 0;		

		tlbhi = faultaddress & TLBHI_VPAGE;
		tlblo = ((newpad<<12) & TLBLO_PPAGE) | TLBLO_VALID;
		
		//DEBUG(DB_VM, "PTEnew\nhi-%x\n",tlbhi);
                //DEBUG(DB_VM, "lo-%x\n",tlblo);
		//DEBUG(DB_VM, "rndmng-");
                        //paddr_t hi,lo;
			//tlb_index = tlb_probe(tlbhi,0);
                        //tlb_read(&hi,&lo,tlb_index);
                        //DEBUG(DB_VM, "%x,%x @%d\n",hi,lo,tlb_index );

                tlb_random(tlbhi, tlblo);
                        //paddr_t hi,lo;
                        //tlb_index = tlb_probe(tlbhi,0);

			//tlb_read(&hi,&lo,tlb_index);
                        //DEBUG(DB_VM, "%x,%x @%d\n",hi,lo,tlb_index );
		//tlb_index = tlb_probe(tlbhi, 0);
                  //      if (tlb_index < 0) {
                    //            tlb_random(tlbhi, tlblo);
                      //  }
                        //else {
                          //      tlb_write(tlbhi, tlblo, tlb_index);
                       // }

                //DEBUG(DB_VM, "-/\n");
		//spinlock_release(&pt_lock);
		//DEBUG(DB_EXEC, "pf:rndm\n");
	}

	else{
		//DEBUG(DB_EXEC, "pf:pt!N\n");
		//Page allocated but not in TLB
		paddr_t pad =pte->paddr<<12;
		vaddr_t vad =faultaddress;
		tlbhi = vad & TLBHI_VPAGE;
		tlblo = (pad & TLBLO_PPAGE) | TLBLO_VALID;
		//if(as->loading)
                 //       tlblo |= TLBLO_DIRTY;

		//DEBUG(DB_VM, "PTEpresent\nhi-%x\n",tlbhi);
                //DEBUG(DB_VM, "lo-%x\n",tlblo);
                //DEBUG(DB_VM, "rndmng-");

		//spl = splhigh();
		tlb_random(tlbhi, tlblo);
		
	    	//tlb_index = tlb_probe(tlbhi, 0);
                  //      if (tlb_index < 0) {
                    //            tlb_random(tlbhi, tlblo);
                      //  }
                        //else {
                          //      tlb_write(tlbhi, tlblo, tlb_index);
                        //}

    //            DEBUG(DB_VM, "-/\n");
	//DEBUG(DB_EXEC, "pf:rndm\n");
	}

        spinlock_release(&as->pt_lock);

	splx(spl);
	return 0;
}



