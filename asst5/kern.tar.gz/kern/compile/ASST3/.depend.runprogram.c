runprogram.o: ../../syscall/runprogram.c ../../include/types.h \
  ../../include/kern/types.h includelinks/kern/machine/types.h \
  includelinks/machine/types.h ../../include/kern/errno.h \
  ../../include/kern/fcntl.h ../../include/kern/unistd.h \
  ../../include/lib.h ../../include/cdefs.h opt-noasserts.h \
  ../../include/proc.h ../../include/spinlock.h \
  includelinks/machine/spinlock.h ../../include/thread.h \
  ../../include/array.h ../../include/threadlist.h \
  includelinks/machine/thread.h ../../include/setjmp.h \
  includelinks/kern/machine/setjmp.h ../../include/current.h \
  includelinks/machine/current.h ../../include/addrspace.h \
  ../../include/vm.h includelinks/machine/vm.h opt-dumbvm.h \
  ../../include/vfs.h ../../include/openfile.h ../../include/filetable.h \
  ../../include/limits.h ../../include/kern/limits.h \
  ../../include/syscall.h ../../include/test.h
